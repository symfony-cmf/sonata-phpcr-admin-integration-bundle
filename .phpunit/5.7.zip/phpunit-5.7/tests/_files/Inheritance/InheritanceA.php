<?php

require_once(__DIR__ . '/InheritanceB.php');

class InheritanceA extends InheritanceB
{
}
